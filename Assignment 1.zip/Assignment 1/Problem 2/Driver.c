#include<stdlib.h>

int main(){
	system("gnome-terminal -- bash -c \"./prob2\"");
	return 0;
}